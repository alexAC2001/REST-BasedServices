package main;

import java.sql.*;

public class ReadAll {

	public static void main(String[] args) throws SQLException {
		
		// Connect to the database
		String dbURL = "jdbc:mysql://localhost:3307/tickets";
		String user = "root";
		String password = "root";
		
		Connection c = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			c = DriverManager.getConnection(dbURL, user, password);
			System.out.println("Successful! " + dbURL + " user= " + user + " pw= " + password);
				
		
		// Create a SQL statement		
		stmt = c.createStatement();
		
		
		// Execute the statement	
		rs = stmt.executeQuery("select * from tickets.tickets");		
		// Process the rows in the result set
		while(rs.next()) {
			System.out.println("id= " + rs.getInt("ORDER_NO") + " title= " + rs.getString("MOVIE_TITLE") + " description= " + rs.getString("PRICE") + " description= " + rs.getString("QUANTITY"));
		}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("FAIL");
			e.printStackTrace();
		}finally {
			// Close the connection to the databse.
			rs.close();
			
			stmt.close();
			
			c.close();
		}

	}

}
