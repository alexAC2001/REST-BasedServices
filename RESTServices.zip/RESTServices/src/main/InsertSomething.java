package main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.faces.bean.ManagedBean;

import beans.Movie;

@ManagedBean
public class InsertSomething {

	public static void main(String[] args) throws SQLException {
		// Connect to the database
		String dbURL = "jdbc:mysql://localhost:3307/tickets";
		String user = "root";
		String password = "root";
		
		Connection c = null;
		Statement stmt = null;
		int rowsAffected = 0;
				
		try {
			c = DriverManager.getConnection(dbURL, user, password);
			System.out.println("Successful! " + dbURL + " user= " + user + " pw= " + password);
				
		// Create a SQL statement		
		stmt = c.createStatement();				
				
		
		// Execute the statement	
		rowsAffected = stmt.executeUpdate("insert into tickets.tickets values (1, 'Avengers', 12.00, 1)");		
		
		// Success message
		System.out.println("Rows affected " + rowsAffected);				
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("FAIL");
			e.printStackTrace();
		}finally {
			// Close the connection to the database.
			
			stmt.close();
					
			c.close();
		}
	}
	// These methods are used for individual buttons that add a specific movie to the purchasedTickets arraylist.
	/*public String onBuy1() throws SQLException {
		String dbURL = "jdbc:mysql://localhost:3307/tickets";
		String user = "root";
		String password = "root";		
		Connection c = null;
		Statement stmt = null;
		int rowsAffected = 0;				
		try {
			c = DriverManager.getConnection(dbURL, user, password);
			//System.out.println("Successful! " + dbURL + " user= " + user + " pw= " + password);
				
		// Create a SQL statement		
		stmt = c.createStatement();				
				
		
		// Execute the statement	
		rowsAffected = stmt.executeUpdate("insert into tickets.tickets values (1, 'Avengers', 15.00, 1)");		
		
		// Success message
		//System.out.println("Rows affected " + rowsAffected);				
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//System.out.println("FAIL");
			e.printStackTrace();
		}finally {
			// Close the connection to the database.
			
			stmt.close();
					
			c.close();
		}
		return "ProductPage.xhtml";
	}*/
}