package main;

import java.sql.SQLException;
import java.util.ArrayList;

import beans.Thing;
import beans.Things;
import beans.Ticket;
import beans.Tickets;
import database.DatabaseService;

public class Demo {

	public static void main(String[] args) throws SQLException {
		DatabaseService ds = new DatabaseService();
		Ticket t = new Ticket(4, "Movie", 8.00, 1, 0);
		
		ArrayList<Ticket> bList = new ArrayList<Ticket>();
 
	    ds.insertOne(t);
		//bList.add(b);		
	    
	    bList = ds.readAll();
		//bList.printAll();
	    System.out.println(" ===========These are a few of my things============");
		for(Ticket mt : bList)
		{
			System.out.println("Order Number: " + mt.getOrderNumber() + " Title: " + mt.getTicketTitle() + " Price: " + mt.getTicketPrice() + " Quantity: " + mt.getTicketQuantity() + " ID: " + mt.getId());
		}
	
		System.out.println(" =========== End of the list===============");

		t = new Ticket(15, "Star Wars", 15.00, 2, 0);
		ds.updateOne(4, t);
	}
}
