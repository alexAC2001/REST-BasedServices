package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.xml.bind.annotation.XmlRootElement;

@ManagedBean
@ViewScoped
@XmlRootElement(name="Ticket")
public class Ticket {

	int orderNumber;
	String ticketTitle;
	double ticketPrice;
	int ticketQuantity;
	int id;
	
	public Ticket(int orderNumber, String ticketTitle, double ticketPrice, int ticketQuantity, int id) {
		super();
		this.orderNumber = orderNumber;
		this.ticketTitle = ticketTitle;
		this.ticketPrice = ticketPrice;
		this.ticketQuantity = ticketQuantity;
		this.id = id;
	}
	// No argument constructor
	public Ticket() {
		
	}
	public int getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getTicketTitle() {
		return ticketTitle;
	}
	public void setTicketTitle(String ticketTitle) {
		this.ticketTitle = ticketTitle;
	}
	public double getTicketPrice() {
		return ticketPrice;
	}
	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}
	public int getTicketQuantity() {
		return ticketQuantity;
	}
	public void setTicketQuantity(int ticketQuantity) {
		this.ticketQuantity = ticketQuantity;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}		
}
