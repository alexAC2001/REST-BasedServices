package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.bean.ReferencedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
//@ViewScoped // CHANGED to SessionScoped
@SessionScoped
//@NotNull()
//@Size(min=5, max=15)
public class User {
	
	// New variables
	public static String username;
	public static String password;
	
	public String firstName;
	public String lastName;
	public String emailAddress;
	public int PhoneNumber;
	public int id;
	
	 public User(String username, String password, String firstName, String lastName, String emailAddress,
			int phoneNumber, int id) {
		super();
		this.username = username;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailAddress = emailAddress;
		this.PhoneNumber = phoneNumber;
		this.id = id;
	}
	/* public static void main(String[] args) {
		    productForm.search();     
		    productForm.ticketNumber();      
		    productForm.showtime();  
		//   buttons
		    productForm.search();  
		    productForm.save();        
		  }
	*/	
	// This is a default constructor that sets the username and password.
	public User() {
		username="user2000";
		password="123";
	}
	// Getters and setters for username and password.
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(int PhoneNumber) {
		this.PhoneNumber = PhoneNumber;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}		
}
