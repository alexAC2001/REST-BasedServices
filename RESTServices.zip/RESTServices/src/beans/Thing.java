package beans;

import javax.faces.bean.ManagedBean;
import javax.xml.bind.annotation.XmlRootElement;

@ManagedBean
@XmlRootElement(name="Thing")
public class Thing {

	int id;
	String thingtitle;
	String thingDescription;
	//int rating;
	
	public int getId() {
		return id;
	}
	public Thing(int id, String thingtitle, String thingDescription) {
		super();
		this.id = id;
		this.thingtitle = thingtitle;
		this.thingDescription = thingDescription;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getThingtitle() {
		return thingtitle;
	}
	public void setThingtitle(String thingtitle) {
		this.thingtitle = thingtitle;
	}
	public String getThingDescription() {
		return thingDescription;
	}
	public void setThingDescription(String thingDescription) {
		this.thingDescription = thingDescription;
	}
	
}
