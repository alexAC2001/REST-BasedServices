package beans;

import java.util.ArrayList;

public class Things {

	ArrayList<Thing> theList = new ArrayList<Thing>();
	
	public void add(Thing bt)
	{
		theList.add(bt);
	}
	
	public void printAll() 
	{
		System.out.println(" ===========These are a few of my things============");
			for(Thing bt : theList)
			{
				System.out.println("ID: " + bt.id + " Title: " + bt.thingtitle + " Desc: " + bt.thingDescription);
			}
		
		System.out.println(" =========== End of the list===============");
	}
	
}
