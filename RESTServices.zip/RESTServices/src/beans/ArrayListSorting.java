package beans;

import beans.Movie;
import java.util.*;
import javax.faces.event.ActionEvent;
//import java.awt.event.ActionEvent;

public class ArrayListSorting {
	
	static ArrayList<Movie> arraylist = new ArrayList<Movie>();

	/*public static void main(String[] args) 
	{	
		   // For testing purposes
		   arraylist.add(new Movie(00, "Movie 1", 10.00, 1, true));
		   arraylist.add(new Movie(01, "Movie 2", 8.50, 1, false));
		   arraylist.add(new Movie(02, "Movie 3", 12.00, 1, true));
		   //Collections.sort(arraylist);
		   for(Movie str: arraylist)
		   {
				System.out.println(str);
		   }
		   System.out.println(arraylist);
	}*/
	/*public boolean checkClicked(ActionEvent ev)
	{
	    String buttonClickedID = ev.getComponent().getClientId();

	    // If the Buy button is clicked, add the movie to the list.
	    if (buttonClickedID.equals("myFormID:myButtonID")) {
	        Movie.isBought = true;
	        arraylist.add(new Movie(int orderNumber, String title, double price, int ticketNumber, boolean isBought));
	    }
	    return Movie.isBought;
	}*/
}
