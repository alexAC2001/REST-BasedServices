package beans;

public class Movie {

	// Properties
	public int orderNumber = 0;
	public String title = "";
	public double price = 0;
	public int ticketNumber = 0;
	public boolean isBought = false;
	public void main(String[] args) 
	{
	}	
	// Constructor with parameters
	public Movie(int orderNumber, String title, double price, int ticketNumber/*, boolean isBought*/) {
		super();
		this.orderNumber = orderNumber;
		this.title = title;
		this.price = price;
		this.ticketNumber = ticketNumber;		
		//this.isBought = isBought;
	}
	// Getters and setters
	public int getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getTicketNumber() {
		return ticketNumber;
	}
	public void setTicketNumber(int ticketNumber) {
		this.ticketNumber = ticketNumber;
	}
	public boolean getisBought() {
		return isBought;
	}
	public void setBought(boolean isBought) {
		this.isBought = isBought;
	}
}
