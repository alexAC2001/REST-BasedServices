package beans;

import java.util.ArrayList;

public class Tickets {

	ArrayList<Ticket> theList = new ArrayList<Ticket>();
	
	public void add(Ticket mt)
	{
		theList.add(mt);
	}
	
	public void printAll() 
	{
		System.out.println(" ===========These are a few of my things============");
			for(Ticket mt : theList)
			{
				System.out.println("Order Number: " + mt.orderNumber + " Title: " + mt.ticketTitle + " Desc: " + mt.ticketPrice + " Quantity: " + mt.ticketQuantity + " ID: " + mt.id);
			}
		
		System.out.println(" =========== End of the list===============");
	}	
}
