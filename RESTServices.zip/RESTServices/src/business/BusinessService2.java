package business;

public class BusinessService2 {

}
