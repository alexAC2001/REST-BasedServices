package business;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import beans.Thing;
import beans.Ticket;

@RequestScoped
@Path("/things")
@Produces({ "application/xml", "application/json" })
@Consumes({ "application/xml", "application/json" })
public class ThingsRestService {

	@Inject
	BusinessServiceInterface bs;
	
	// Get all records and display them in json format
	@GET
	@Path("/getjson")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Ticket> getAllTicketsAsJson() {
		return bs.readAll();
	}
	
	// Get one record by its id number and display it in json format
		/*@GET
		@Path("/getjsonbyid/{id}")
		@Produces(MediaType.APPLICATION_JSON)
		public List<Ticket> getOneTicketsAsJson (@PathParam("id") int id) {
			return bs.readOne(int id);
		}*/
	// Get all records and display them in json format
		@GET
		@Path("/getxml")
		@Produces(MediaType.APPLICATION_XML)
		public Ticket[] getAllTicketsAsXML() {
			List<Ticket> tickets = bs.readAll();
			return tickets.toArray(new Ticket[tickets.size()]);
		}
}
