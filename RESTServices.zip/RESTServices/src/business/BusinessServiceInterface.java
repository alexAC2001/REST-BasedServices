package business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.jms.Message;

import beans.Order;
import beans.Thing;
import beans.Ticket;
@Stateless
@Local
@Alternative
public interface BusinessServiceInterface {

	public void test();
	public List<Order> getOrder();
	public void setOrders(List<Order> orders);
	
	public int deleteOne(int d);	
	public int insertOne(Thing t);	
	public ArrayList<Ticket> readAll();	
	public int updateOne(int d, Thing t);
	public Ticket readOne(int id);	
	public Ticket sendOrder(Ticket ticket);
	Ticket onMessage(Message TextMessage);
}
