package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Ticket;
import beans.User;
//import beans.Tickets;

@Stateless
@Local
@Alternative

public class DatabaseService implements DatabaseInterface{
	// Connect to the database
	String dbURL = "jdbc:mysql://localhost:3307/tickets";
	String user = "root";
	String password = "root";
					
	// Four crud operations
	
	/*public deleteOne(int id) {
		int numberOfRowsAffected = 0;
		
		// Database work		
		
		
		return numberOfRowsAffected;
	}*/	
	public int insertOne(Ticket t) {
		int numberOfRowsAffected = 0;		
		// Database work
		Connection c = null;
		PreparedStatement stmt = null;
		int rowsAffected = 0;						
				try {
					c = DriverManager.getConnection(dbURL, user, password);
					System.out.println("INSERT Successful! " + dbURL + " user= " + user + " pw= " + password);
						
				// Create a SQL statement		
				stmt = c.prepareStatement("insert into tickets.tickets values (?, ?, ?, ?, null)");				
				
				stmt.setInt(1, t.getOrderNumber());
				stmt.setString(2, t.getTicketTitle());
				stmt.setDouble(3, t.getTicketPrice());
				stmt.setInt(4, t.getTicketQuantity());
				// Execute the statement	
				rowsAffected = stmt.executeUpdate();						
				// Success message
				System.out.println("Rows inserted " + rowsAffected);				
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println("FAIL");
					e.printStackTrace();
				}finally {
					// Close the connection to the database.					
					try {
						stmt.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}							
					try {
						c.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}		
				}		
		return numberOfRowsAffected;
	}	
	public ArrayList<Ticket> readAll() {
		ArrayList<Ticket> everyone = new ArrayList<>();
		Ticket t;

		Connection c = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			c = DriverManager.getConnection(dbURL, user, password);
			System.out.println("Connection is Successful! " + dbURL + " user= " + user + " pw= " + password);
				
		// Create a SQL statement		
		stmt = c.createStatement();				

		// Execute the statement	
		rs = stmt.executeQuery("select * from tickets.tickets");						
		// Print rows in the result set
		while(rs.next()) {
			System.out.println("#: " + rs.getInt("ORDER_NO") + " Title: " + rs.getString("MOVIE_TITLE") + " Price: " + rs.getDouble("PRICE") + " Quantity: " + rs.getInt("QUANTITY"));
			
			t = new Ticket(rs.getInt("ORDER_NO"), rs.getString("MOVIE_TITLE"), rs.getDouble("PRICE"), rs.getInt("QUANTITY"), rs.getInt("id"));
			everyone.add(t);
		}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("FAIL");
			e.printStackTrace();
		}finally {
			// Close the connection to the database.					
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}							
			try {
				c.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
		}		
		return everyone;
	}	
	public int updateOne(int id, Ticket t) throws SQLException {
		int numberOfRowsAffected = 0;		
		// Database work
				
		Connection c = null;
		PreparedStatement stmt = null;
		int rowsAffected = 0;						
				try {
					c = DriverManager.getConnection(dbURL, user, password);
					System.out.println("INSERT Successful! " + dbURL + " user= " + user + " pw= " + password);
						
				// Create a SQL statement		
				stmt = c.prepareStatement("update tickets.tickets set ORDER_NUMBER = ?, where MOVIE_TITLE = ?, where PRICE = ?, where QUANTITY = ?, where id = ?");				
				stmt.setInt((1), t.getOrderNumber());
				stmt.setString(2, t.getTicketTitle());
				stmt.setDouble(3, t.getTicketPrice());
				stmt.setInt(4, t.getTicketQuantity());;
				stmt.setInt(5, id);
				// Execute the statement	
				rowsAffected = stmt.executeUpdate();						
				// Success message
				System.out.println("Rows affected " + rowsAffected);				
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println("Error communicating with the database");
					e.printStackTrace();
				}finally {
					// Close the connection to the database.					
					stmt.close();							
					c.close();				
				}
		return numberOfRowsAffected;
	}
	@Override
	public int deleteOne(int d) {
		// TODO Auto-generated method stub
		return 0;
	}
	// Get one record from the db and return it
	@Override
	public Ticket readOne(int id) {
		Ticket t = null;

		Connection c = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			c = DriverManager.getConnection(dbURL, user, password);
			System.out.println("Connection is Successful! " + dbURL + " user= " + user + " pw= " + password);
				
		// Create a SQL statement		
		stmt = c.prepareStatement("select * from tickets.tickets WHERE id =?");				
		stmt.setInt(1, id);			
		
		rs = stmt.executeQuery();
		// Print rows in the result set
		while(rs.next()) {
			System.out.println("#: " + rs.getInt("ORDER_NO") + " Title: " + rs.getString("MOVIE_TITLE") + " Price: " + rs.getDouble("PRICE") + " Quantity: " + rs.getInt("QUANTITY"));
			
			t = new Ticket(rs.getInt("ORDER_NO"), rs.getString("MOVIE_TITLE"), rs.getDouble("PRICE"), rs.getInt("QUANTITY"), rs.getInt("id"));
		}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("FAIL");
			e.printStackTrace();
		}finally {
			// Close the connection to the database.					
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}							
			try {
				c.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
		}		
		return t; // return a single item, t		
	}	
}
