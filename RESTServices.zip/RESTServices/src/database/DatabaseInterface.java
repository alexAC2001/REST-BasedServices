package database;

import java.util.ArrayList;

import javax.ejb.Local;

import beans.Thing;
import beans.Ticket;

@Local
public interface DatabaseInterface {

Ticket TextMessage = null;

public int deleteOne(int d);
	
	public int insertOne(Ticket t);
	
	public ArrayList<Ticket> readAll();

	public Ticket readOne(int id);
	
	//public int updateOne(int d, Thing t);
	
}
